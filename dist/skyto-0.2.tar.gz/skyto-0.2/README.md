# Skyto 🌿

**Skyto** est un langage de programmation en lingala, pour apprendre la programmation et faire de l'intelligence artificielle.

## Exemple :

```skyto
tala conseil(h, ph, temp):
    importa skyto._modules
    zongisa skyto._modules.conseiller_type_sol(h, ph, temp)

monisa(conseil(35, 6.1, 26))
```
